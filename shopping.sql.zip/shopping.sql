-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Июн 17 2014 г., 11:29
-- Версия сервера: 5.1.40
-- Версия PHP: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `shopping`
--

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name_goods` text NOT NULL,
  `price` float NOT NULL,
  `measure` text NOT NULL,
  `qti` float NOT NULL,
  `id_list` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=89 ;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id`, `name_goods`, `price`, `measure`, `qti`, `id_list`) VALUES
(40, 'Кирпич', 2, 'шт', 1000, 2),
(81, '', 0, '', 0, 3),
(82, '', 0, '', 0, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `list`
--

CREATE TABLE IF NOT EXISTS `list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `user_id` int(10) NOT NULL,
  `bloc` int(1) NOT NULL DEFAULT '0',
  `last_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `bloc_user_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `list`
--

INSERT INTO `list` (`id`, `name`, `user_id`, `bloc`, `last_upd`, `bloc_user_id`) VALUES
(2, '123', 1, 1, '0000-00-00 00:00:00', 1),
(3, '123', 1, 1, '0000-00-00 00:00:00', 0),
(4, 'test', 1, 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `list_user`
--

CREATE TABLE IF NOT EXISTS `list_user` (
  `user_id` int(10) NOT NULL,
  `list_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `list_user`
--

INSERT INTO `list_user` (`user_id`, `list_id`) VALUES
(1, 2),
(4, 5),
(7, 8),
(7, 0),
(7, 0),
(7, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `password`) VALUES
(1, 'sersergei', 'sersergei@bigmir.net', '98dae0e08c01f9e64dc3f9650eb5a714'),
(7, 'test', 'test@me.gov', '098f6bcd4621d373cade4e832627b4f6'),
(8, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(9, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(10, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(11, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(12, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(13, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(14, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a'),
(15, 'test1', 'test1@nf.nf', '5a105e8b9d40e1329780d62ea2265d8a');
